#!/usr/bin/env python
# coding: utf-8

# In[1]:


odd = 0
even = 0
no_parity = 0
palindrome = 0
non_palindrome = 0

def isParity(value):
    global odd,even,no_parity
    if (value.isdigit()):
        
        if int(value) % 2 == 0:
            even += 1
            return value + ' has even parity'
        else:
            odd += 1
            return value + ' has odd parity'
        
    else:
        no_parity += 1
        return value + ' cannot have parity'

def  isPalindrome(word):
    global palindrome, non_palindrome
    if word == None:
        non_palindrome += 1
        return 'not palindrome'
    i = 0
    n = len(word)
    while i < (n/2):
        if word[i] != word[n-1-i]:
            non_palindrome += 1
            return ' and ' + word +' is not palindrome'
        
        i += 1
    else:
        palindrome += 1
        return ' and ' + word +' is a palindrome'
data = open("LAb1input.txt")
f_data = data.read()
file = open("output.txt",'w')

idata = f_data.split('\n')
for i in idata:
    i = i.split(' ')
    out1 = isParity(i[0])+isPalindrome(i[1])
    file.write(out1)
    file.write('\n')
file.close()

calc_odd = int(odd/(odd + even + no_parity) * 100)
calc_even = int(even/(odd + even + no_parity) * 100)
calc_no_parity = int(odd/(odd + even + no_parity) * 100)
calc_palindrome = int(palindrome/(palindrome + non_palindrome) * 100)
calc_non_palindrome = int(non_palindrome/(palindrome + non_palindrome) * 100)

file1 = open("record.txt",'w')
file1.write('Percentage of odd parity: '+ str(calc_odd)+'%'+'\n')
file1.write('Percentage of even parity: '+ str(calc_even)+'%'+'\n')
file1.write('Percentage of no parity: '+ str(calc_no_parity)+'%'+'\n')
file1.write('Percentage of palindrome: ' + str(calc_palindrome) + '%'+'\n')
file1.write('Percentage of non-palindrome: '+ str(calc_non_palindrome) + '%'+'\n')
file1.close()


# In[ ]:





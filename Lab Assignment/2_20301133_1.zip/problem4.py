#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as npy

def matrix_Multiply(a,b):
    result = []
    ele = []
    n = len(a)
    for i in range(n):
        ele = [0]*n
        result.append(ele)
    
    for i in range(n):
        for j in range(n):
            for k in range(n):
                result[i][j] += int(a[i][k]) * int(b[k][j])
                
    return result

    
file_1 = open ("input4a.txt",'r')
matrix_a = []
for val1 in file_1:
    l1 = val1.split()
    matrix_a.append(l1)

file_2 = open ("input4b.txt",'r')
matrix_b = []
for val2 in file_2:
    l2 = val2.split()
    matrix_b.append(l2)
    
file_o = open("output4.txt",'a')
calc = matrix_Multiply(matrix_a,matrix_b)
file_o.write(str(npy.array(calc)))
file_o.close()


# In[ ]:





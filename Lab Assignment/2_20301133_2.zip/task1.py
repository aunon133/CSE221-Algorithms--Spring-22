#!/usr/bin/env python
# coding: utf-8

# In[2]:


def bubbleSort(arr):
    for i in range(len(arr)-1):
        exchng = False
        for j in range(len(arr)-i-1):
            if arr[j] > arr[j+1] :
                arr[j], arr[j+1] = arr[j+1], arr[j]
                exchng = True
        if exchng == False:
            break       
    return arr

file_i = open ("input1.txt")
lines = file_i.readlines()
lst = []

for i in lines[1].split() :
    lst.append(int(i))
file_i.close()

file_o = open("output1.txt",'w')
output = bubbleSort(lst)
for j in output:
    file_o.write(str(j) + ' ')
file_o.close()


# In[ ]:





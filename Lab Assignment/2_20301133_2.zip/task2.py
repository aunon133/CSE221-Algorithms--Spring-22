#!/usr/bin/env python
# coding: utf-8

# In[2]:


def selectionSort(arr, rng):
    for i in range(len(arr)):
        min_idx = i
        for j in range(i+1, len(arr)):
            if arr[min_idx] > arr[j]:
                min_idx = j       
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
        
    return arr[0:rng]

file_i = open ("E:\\Lab2\\input2.txt")
lines = file_i.readlines()

info = []
for i in lines[0].split():
    info.append(int(i))
    
lst2 = []
for j in lines[1].split():
    lst2.append(int(j))
file_i.close()
    
file_o = open("E:\\Lab2\\output2.txt",'w')
output = selectionSort(lst2,info[1])
for k in output:
    file_o.write(str(k) + ' ')
file_o.close()


# In[ ]:





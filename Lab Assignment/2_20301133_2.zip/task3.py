#!/usr/bin/env python
# coding: utf-8

# In[1]:


def insertionSort(arr1,arr2):
    for i in range(0,len(arr2)-1):
        key = arr2[i+1]
        for j in range(i,-1,-1):
            if arr2[j] < key:
                arr2[j], arr2[j + 1] = arr2[j + 1], arr2[j]
                arr1[j], arr1[j + 1] = arr1[j + 1], arr1[j]
                key = arr2[j]
            else:
                break
                
    return arr1

file_i = open ("E:\\Lab2\\input3.txt")
lines = file_i.readlines()

lst1 = []
for i in lines[1].split():
    lst1.append(int(i))
        
lst2 = []
for j in lines[2].split():
    lst2.append(int(j))
file_i.close()

file_o = open("E:\\Lab2\\output3.txt",'w')
output = insertionSort(lst1,lst2)
for k in output:
    file_o.write(str(k) + ' ')
file_o.close()


# In[ ]:





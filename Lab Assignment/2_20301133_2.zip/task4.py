#!/usr/bin/env python
# coding: utf-8

# In[2]:


def merge(arr, p, q, r):
    n1 = q - p + 1
    n2 = r - q
    left = [0] * n1
    right = [0] * n2
    
    for i in range(0, n1):
        left[i] = arr[p + i]
    for j in range(0, n2):
        right[j] = arr[q + 1 + j]
        
    i = 0
    j = 0
    k = p
    while (i < len(left) and j < len(right)):   
        
        if left[i] <= right[j]:
            arr[k] = left[i]
            i += 1
        else:
            arr[k] = right[j]
            j += 1
        k += 1
        
    while i < len(left):
        arr[k] = left[i]
        i += 1
        k += 1

    while j < len(right):
        arr[k] = right[j]
        j += 1
        k += 1
        
def merge_sort(arr, p, r):
    if p < r:
        q = (p+(r-1))//2
        merge_sort(arr, p, q)
        merge_sort(arr, q + 1, r)
        merge(arr, p, q, r)
        
file_i = open ("E:\\Lab2\\input4.txt")
lines = file_i.readlines()

lst1 = []
for i in lines[1].split():
    lst1.append(int(i))

file_o = open("E:\\Lab2\\output4.txt",'w')
merge_sort(lst1,0,len(lst1)-1)
for k in lst1:
    file_o.write(str(k) + ' ')
file_o.close()


# In[ ]:





#!/usr/bin/env python
# coding: utf-8

# In[2]:


import time
start_time = time.time()

def partition(arr, p, q):
    pivot = arr[p]
    i = p
    for j in range(p+1, q+1):
        if arr[j] <= pivot:
            i = i + 1
            arr[j], arr[i] = arr[i], arr[j]

    arr[i], arr[p] = arr[p], arr[i]
    return i
    
def quickSort(arr, p, r):
    if p < r:
        q = partition(arr, p, r)
        quickSort(arr, p, q-1)
        quickSort(arr, q+1, r)

arr = [5,-2,1,7,2,1]
n = len(arr)
print('Unsorted Array:',arr)
quickSort(arr,0,n-1)
print('Sorted Array:',arr)
print("Execution time : " + str((time.time() - start_time)))


# In[ ]:





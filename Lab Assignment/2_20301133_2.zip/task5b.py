#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def partition(arr, p, q):
    pivot = arr[p]
    i = p
    for j in range(p+1, q+1):
        if arr[j] <= pivot:
            i = i + 1
            arr[j], arr[i] = arr[i], arr[j]

    arr[i], arr[p] = arr[p], arr[i]
    return i

def findk(arr, l, r, k):
    p = partition(arr,l,r)
    c = p - l + 1
    if l == r:
        return arr[l]
    if c == k :
        return arr[p]
    elif c > k:
        return findk(arr, l, p-1, k)
    else:
        return findk(arr, p+1, r, k-c)
    
arr = [1,3,4,5,9,7,10]
print(findk(arr, 0, len(arr)-1, 2))
print(findk(arr, 0, len(arr)-1, 5))
print(findk(arr, 0, len(arr)-1, 7))


# In[ ]:





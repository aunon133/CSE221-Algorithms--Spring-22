


file_i = open("input.txt",'r')
file_o = open("output-task1.txt",'w')
line1 = file_i.readline()
line2 = file_i.readline()
graph = {}

for i in range(1,int(line1)+1):
    graph[i] = []
    
for j in range(int(line2)):
    line = file_i.readline()
    s = line.split()
    u, v = int(s[0]), int(s[1])

    if u in graph:
        graph[u].append(v)
    else:
        graph[u] = [v]
    
file_o.write(str(graph))
    
file_i.close()
file_o.close()








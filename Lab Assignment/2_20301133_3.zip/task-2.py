


file_i = open("input.txt",'r')
file_o = open("output-task2.txt",'w')
line1 = file_i.readline()
line2 = file_i.readline()
graph = {}

for i in range(1,int(line1)+1):
    graph[i] = []
    
for j in range(int(line2)):
    line = file_i.readline()
    s = line.split()
    u, v = int(s[0]), int(s[1])

    if u in graph:
        graph[u].append(v)
    else:
        graph[u] = [v]

visited = [0]*int(line1)
queue = []
def BFS(visited, graph, node, endPoint):
    visited[int(node)-1] = 1
    queue.append(int(node))
    file_o.write('Places: ')
    while len(queue) != 0:
        m = queue.pop(0)
        file_o.write(str(m) + ' ')
        if m == endPoint:
            break
        for neighbour in graph[m]:
            if visited[int(neighbour)-1] == 0:
                visited[int(neighbour)-1] = 1
                queue.append(neighbour)
                
BFS(visited,graph,1,12)
file_i.close()
file_o.close()








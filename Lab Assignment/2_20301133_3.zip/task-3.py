


file_i = open("input.txt",'r')
file_o = open("output-task3.txt",'w')
line1 = file_i.readline()
line2 = file_i.readline()
graph = {}

for i in range(1,int(line1)+1):
    graph[i] = []
    
for j in range(int(line2)):
    line = file_i.readline()
    s = line.split()
    u, v = int(s[0]), int(s[1])

    if u in graph:
        graph[u].append(v)
    else:
        graph[u] = [v]
        
visited = [0]*int(line1)
printed = []
def DFS_VISIT(graph,node):
    visited[int(node)-1] = 1
    printed.append(int(node))
    for i in graph[node]:
        if i not in visited:
            DFS_VISIT(graph,i)
def DFS(graph,endPoint):
    for j in graph:
        if j not in visited:
            DFS_VISIT(graph,j)
            
    end = printed.index(endPoint)
    file_o.write('Places: ')
    for k in range(0, end+1):
        file_o.write(str(printed[k]) + ' ')
DFS(graph,12)
file_i.close()
file_o.close()








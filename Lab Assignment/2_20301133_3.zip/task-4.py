#!/usr/bin/env python
# coding: utf-8

# In[3]:


file_i = open("input-task4.txt",'r')
file_o = open("output-task4.txt",'w')
line = file_i.readline()
graph = {}
for i in range(int(line)):
    line1 = file_i.readline()
    s = line1.split()
    n, m = int(s[0]), int(s[1])
    for k in range(1,n+1):
        graph[k] = []
    for j in range(m):
        x = file_i.readline()
        a = x.split()
        u, v = int(a[0]), int(a[1])
        if u in graph:
            graph[u].append(v)
        else:
            graph[u] = [v]

        if v in graph:
            graph[v].append(u)
        else:
            graph[v] = [u]
            
    q = []
    visited = [0] * n
    d_time = [0] * n
    def shortest_path(graph, visited, node, endPoint):
        visited[node-1] = 1
        q.append(node)
        while len(q) != 0:
            m = q.pop()
            neighbour = graph.get(int(m))
            for i in neighbour:
                if visited[i-1] == 0:
                    visited[i-1] = 1
                    q.append(i)
                    d_time[i-1] = d_time[m-1] + 1

        file_o.write(str(d_time[-1]) + '\n')

    shortest_path(graph, visited, 1, n)
file_i.close()
file_o.close()   


# In[ ]:








def dijkstra(graph, source):
    dist = {}
    dist[source] = 0
    prev = {}
    pq = []
    for v in graph:
        if v != source:
            dist[v] = float('inf')
            prev[v] = None
        pq.append(v)

    while len(pq) != 0:
        temp = {}
        for i in pq:
            temp.update({i: dist[i]})
        m = min(temp, key = temp.get)
        pq.remove(m)
        for keys, vals in graph[m].items():
            obj = dist[m] + vals
            if obj < dist[keys]:
                dist[keys] = obj
                prev[keys] = m

    return list(dist.values())

f_i = open("input1.txt",'r')
f_o = open("output1.txt",'w')
l = f_i.readline()
graph = {}
for i in range(int(l)):
    l1 = f_i.readline()
    s = l1.split()
    n, m = int(s[0]), int(s[1])
    for k in range(1,n+1):
        graph[k] = {}
    for j in range(m):
        x = f_i.readline()
        a = x.split()
        u, v, w = int(a[0]), int(a[1]), int(a[2])
        if u not in graph:
            graph[u] = {}
        graph[u][v] = w

    temp = dijkstra(graph, 1)
    f_o.write(str(temp[-1]) + '\n')
    
f_i.close()
f_o.close()


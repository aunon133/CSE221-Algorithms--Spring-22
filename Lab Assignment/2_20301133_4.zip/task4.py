


def dijkstra(graph, source):
    dist = {}
    dist[source] = 0
    prev = {}
    pq = []
    for v in graph:
        if v != source:
            dist[v] = float('inf')
            prev[v] = None
        pq.append(v)

    while len(pq) != 0:
        temp = {}
        for i in pq:
            temp.update({i: dist[i]})
        m = min(temp, key = temp.get)
        pq.remove(m)
        for keys, vals in graph[m].items():
            obj = dist[m] + vals
            if obj < dist[keys]:
                dist[keys] = obj
                prev[keys] = m
      
    return dist, prev

f_i = open("input4.txt",'r')
f_o = open('output4.txt','w')

graph = {}
for i in range(18):
    l = f_i.readline()
    a = l.split()
    u, v, w = a[0], a[1], int(a[2])
    if u not in graph:
        graph[u] = {}
    if v not in graph:
        graph[v] = {}
    graph[u][v] = w
    
t = dijkstra(graph,'Motijheel')
f_o.write('Minimum traffic: '+ str(t[0].get('MOGHBAZAR')) + '\n')
temp = t[1]
k = ['MOGHBAZAR']
x = "MOGHBAZAR"
for j in range(0,len(temp)):
    for key,val in temp.items():
        if key == x:
            x = val
            k.append(val)
obj = k[::-1]
f_o.write('Shorest path: ')
for z in obj:
    f_o.write(z + ' ')
        
f_i.close()
f_o.close()


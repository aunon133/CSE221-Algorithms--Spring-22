


import heapq


def network(graph, source):
    dist = {source: float('inf')}
    pq = []
    prev = {}
    visited = []
    for i in range(len(graph) + 1):
        visited.append(False)

    for v in graph:
        if v != source:
            dist[v] = float('-inf')
        prev[v] = None

    heapq.heappush(pq, source)
    while len(pq) != 0:
        m = heapq._heappop_max(pq)
        if not visited[m]:
            visited[m] = True
            for key, value in graph[m].items():
                low = min(dist[m], value)
                if low > dist[key]:
                    prev[key] = m
                    dist[key] = low
                    heapq.heappush(pq, key)
                    heapq._heapify_max(pq)

    for j in range(1, len(graph)):
        if dist[j] == float('-inf'):
            dist[j] = -1

    dist[source] = 0
    temp = [dist[k] for k in range(1, len(graph) + 1)]
    return temp


def print_Output(graph, source):
    global obj
    temp1 = ""
    link = network(graph, source)
    for k in link:
        temp1 += str(k) + " "

    obj += temp1 + "\n"
    
obj = ''
f_i = open("input5.txt",'r')
f_o = open("output5.txt", "w")
l = int(f_i.readline())

for i in range(l):
    lines = f_i.readline().split()

    if lines[1] == 0:
        s = int(f_i.readline())
        graph = {lines[0]: {}}  
        print_Output(graph, source)
    else:
        graph = {}
        for j in range(int(lines[1])):
            edges = f_i.readline().split()
            graph[(int(edges[0]), int(edges[1]))] = int(edges[2])

        n = []
        for k in range(1, int(lines[0]) + 1):
            n.append(k)

        adj = {}
        for v in n:
            adj.update({v: {}})

        for (u, x), w in graph.items():
            adj[u][x] = w
        source = int(f_i.readline())
        print_Output(adj, source)

f_o.write(obj)
f_i.close()
f_o.close()


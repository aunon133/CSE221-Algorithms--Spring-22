


file_i = open('task1_input.txt','r')
file_o = open('task1_output.txt','w')
line = file_i.readline()
lst = []
for i in range(int(line)):
    l1 = file_i.readline()
    l1 = l1.split()
    a, b = int(l1[0]), int(l1[1])
    tup = (a,b)
    lst.append(tup)
    lst.sort(key = lambda x: x[1])

selected = []
selected.append(lst[0])
count = 1
f = lst[0][1]
for j in range(1,len(lst)):
    if lst[j][0] >= f:
        count += 1
        f = lst[j][1]
        selected.append(lst[j])

file_o.write(str(count) + '\n')

k = 0
for i in range(len(selected)):
    temp = str(selected[i][k]) + ' ' + str(selected[i][k+1]) + '\n'
    file_o.write(temp)

file_i.close()
file_o.close()


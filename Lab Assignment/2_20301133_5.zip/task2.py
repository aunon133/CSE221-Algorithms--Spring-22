


file_i = open('task2_input.txt','r')
file_o = open('task2_output.txt','w')
line = file_i.readline()
line = line.split()
lst = []
for i in range(int(line[0])):
    l1 = file_i.readline()
    l1 = l1.split()
    a, b = int(l1[0]), int(l1[1])
    tup = (a,b)
    lst.append(tup)
    lst.sort(key = lambda x: x[1])

days = []
for j in range(int(line[1])):
    days.append(0)

count = 0
for i in range(len(lst)):
    for j in range(len(days)):
        if lst[i][0] >= days[j]:
            days[j] = lst[i][1]
            count += 1
            break
            
file_o.write(str(count))

file_i.close()
file_o.close()


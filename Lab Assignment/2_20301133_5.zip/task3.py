


file_i = open('task3_input.txt','r')
file_o = open('task3_output.txt','w')

l = file_i.readline()
l1 = file_i.readline()
l1 = l1.split()
l2 = file_i.readline()

lst = []
for i in l1:
    lst.append(int(i))
    
lst.sort()

stack = []
k = 0
seq = ''
jack = []
jill = []
for j in range(len(l2)):
    if l2[j] == 'J':
        stack.append(lst[k])
        seq += str(lst[k])
        jack.append(lst[k])
        k += 1
    else:
        m = stack.pop()
        seq += str(m)
        jill.append(m)

t1 = sum(jack)
t2 = sum(jill)

file_o.write(str(seq) + '\n')
file_o.write('Jack will work for ' + str(t1) + ' hours' + '\n')
file_o.write('Jill will work for ' + str(t2) + ' hours' + '\n')

file_i.close()
file_o.close()


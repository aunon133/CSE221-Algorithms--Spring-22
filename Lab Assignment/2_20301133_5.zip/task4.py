


import math

file_i = open('task4_input.txt','r')
file_o = open('task4_output.txt','w')

while True:
    line = file_i.readline()
    line = line.split()
    a, b = int(line[0]), int(line[1])
    if a == 0 and b == 0:
        break
    else:
        count = 0
        i = math.sqrt(a)
        while (i*i <= b):
            count += 1
            i += 1

    file_o.write(str(count) + '\n')

file_i.close()
file_o.close()


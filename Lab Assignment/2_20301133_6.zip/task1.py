


file_i = open('task-1_input.txt','r')
file_o = open('task-1_output.txt','w')
n = int(file_i.readline())
count = 0
seq = str(n) + '->' + ''
while n > 0:
    maximum = int(max(list(str(n))))
    n = n - maximum
    count += 1
    if n > 0:
        seq += str(n) + '->'
    if n == 0:
        seq += '0'
    
file_o.write('Minimum number of steps: ' + str(count) + '\n')
file_o.write('Steps are: ' + str(seq))

file_i.close()
file_o.close()


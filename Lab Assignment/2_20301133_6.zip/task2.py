


file_i = open('task-2_input.txt','r')
file_o = open('task-2_output.txt','w')
line0 = file_i.readline()
line1 = file_i.readline().strip()
line2 = file_i.readline().strip()
places_dict = {"Y":"Yasnaya","P":"Pochinki","S":"School","R":"Rozhok","F":"Farm","M":"Mylta","H":"Shelter","I":"Prison"}

def LCS(x,y):
    m = len(x) + 1
    n = len(y) + 1
    c = [[0 for i in range(m)] for j in range(n)]
 
    for i in range(1,m):
        for j in range(1,n):
            if x[i-1] == y[j-1]:
                c[i][j] = c[i-1][j-1] + 1

            elif c[i-1][j] > c[i][j-1]:
                c[i][j] = c[i-1][j]

            else:
                c[i][j] = c[i][j-1]
 
    correctness = (c[m-1][n-1]/int(line0))*100
    st = ''
    x1 = m - 1
    y1 = n - 1
    
    while x1 > 0 and y1 > 0:
        if x[x1-1] == y[y1-1]:
            st += x[x1-1]
            x1 = x1-1
            y1 = y1-1
        elif c[x1-1][y1] > c[x1][y1-1]:
            x1 = x1-1
        else:
            y1 = y1-1
    seq = ''
    for i in st[-1::-1]:
        seq += places_dict[i] + ' '
    file_o.write(seq + '\n')
    file_o.write('Correctness of prediction:' + str(correctness) + '%')

LCS(line1,line2)

file_i.close()
file_o.close()


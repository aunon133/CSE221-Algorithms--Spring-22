


file_i = open('task-3_input.txt','r')
file_o = open('task-3_output.txt','w')
line0 = file_i.readline().strip()
line1 = file_i.readline().strip()
line2 = file_i.readline().strip()

def LCS(x,y,z):
    m = len(x) + 1
    n = len(y) + 1
    o = len(z) + 1

    c = [[[0 for i in range(o)] for j in range(n)] for k in range(m)]
    
    for i in range(1,m):
        for j in range(1,n):
            for k in range(1,o):
                if i == 0 or j == 0 or k == 0:
                    c[i][j][k] = 0
                else:
                    if x[i-1] == y[j-1] and x[i-1] == z[k-1]:
                        c[i][j][k] = 1 + c[i-1][j-1][k-1]
                    else:
                        if c[i-1][j][k] >= c[i][j-1][k]:
                            mx = c[i-1][j][k]
                            if mx >= c[i][j][k-1]:
                                c[i][j][k] = mx
                            else:
                                mx = c[i][j][k-1]
                                c[i][j][k] = mx
                        else:
                            mx = c[i][j-1][k]
                            if mx >= c[i][j][k-1]:
                                c[i][j][k] = mx
                            else:
                                mx = c[i][j][k-1]
                                c[i][j][k] = mx
    return c[m-1][n-1][o-1]
                                 
file_o.write(str(LCS(line0,line1,line2)))
             
file_i.close()
file_o.close()

